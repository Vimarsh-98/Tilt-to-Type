package com.eecs4443.tilttotype;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class SetupActivity extends Activity {
    String[] participantCode = {"P01", "P02", "P03", "P04", "P05", "P06"};
    String[] sessionCode = {"S01", "S02", "S03", "S04", "S05"};
    String[] groupCode = {"G1", "G2"};
    String[] trialCode = {"T1", "T2"};
    String[] phrasesCode = {"phrase1", "phrase2"};

    private Spinner spinParticipantCode, spinSessionCode, spinGroupCode, trialSessionCode, phraseSessionCode;
    private RadioGroup modeSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setup_layout);

        // get references to widgets in setup dialog
        spinParticipantCode = (Spinner)findViewById(R.id.participantSpin);
        spinSessionCode = (Spinner)findViewById(R.id.sessionSpin);
        spinGroupCode = (Spinner)findViewById(R.id.groupSpin);
        trialSessionCode = (Spinner)findViewById(R.id.trialSpin);
        modeSelect = findViewById(R.id.modeRadio);
        phraseSessionCode = (Spinner)findViewById(R.id.phraseSpin);

        // initialise spinner adapters
        ArrayAdapter<CharSequence> adapterPC = new ArrayAdapter<CharSequence>(this, R.layout.spinner_item, participantCode);
        spinParticipantCode.setAdapter(adapterPC);

        ArrayAdapter<CharSequence> adapterSC = new ArrayAdapter<CharSequence>(this, R.layout.spinner_item, sessionCode);
        spinSessionCode.setAdapter(adapterSC);

        ArrayAdapter<CharSequence> adapterGC = new ArrayAdapter<CharSequence>(this, R.layout.spinner_item, groupCode);
        spinGroupCode.setAdapter(adapterGC);

        ArrayAdapter<CharSequence> adapterTC = new ArrayAdapter<CharSequence>(this, R.layout.spinner_item, trialCode);
        trialSessionCode.setAdapter(adapterTC);

        ArrayAdapter<CharSequence> adapterPhC = new ArrayAdapter<CharSequence>(this, R.layout.spinner_item, phrasesCode);
        phraseSessionCode.setAdapter(adapterPhC);
    }

    public void onClick(View v)
    {
        String part = participantCode[spinParticipantCode.getSelectedItemPosition()];
        String sess = sessionCode[spinSessionCode.getSelectedItemPosition()];
        String group = groupCode[spinGroupCode.getSelectedItemPosition()];
        String trial = trialCode[trialSessionCode.getSelectedItemPosition()];
        String phrases = phrasesCode[phraseSessionCode.getSelectedItemPosition()];
        boolean tiltMode = false;
        if (modeSelect.getCheckedRadioButtonId() == R.id.tiltMode)
            tiltMode = true;

        Bundle b = new Bundle();
        b.putString("participantCode", part);
        b.putString("sessionCode", sess);
        b.putString("groupCode", group);
        b.putString("trialCode", trial);
        b.putString("phrasesCode", phrases);
        b.putBoolean("tiltMode", tiltMode);


        Intent i = new Intent(getApplicationContext(), KeyboardActivity.class);
        i.putExtras(b);
        startActivity(i);
    }
}
