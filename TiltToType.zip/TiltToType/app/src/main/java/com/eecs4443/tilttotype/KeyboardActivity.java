package com.eecs4443.tilttotype;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.NoCopySpan;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class KeyboardActivity extends AppCompatActivity implements SensorEventListener, TextWatcher {
    private final static String MYDEBUG = "MYDEBUG"; // for Log.i messages
    private final static String APP = "TiltToType";
    private final static String DATA_DIRECTORY = "/TiltToTypeData/";
    private final static String SD2_HEADER = "App,Participant,Session,Block,Group,"
            + "Keystrokes,Characters,Time(s),Speed(wpm),ErrorRate(%),KSPC\n";

    private final int KEYBOARD_ROWS = 5;
    private final int KEYBOARD_COLS = 10;

    private final int SPACE_ROW = 4;
    private final int SPACE_COL = 2;
    private final int SPACE_WIDTH = 5; //number of EXTRA key widths the spacebar takes

    private final float RADIANS_TO_DEGREES = 57.2957795f;
    private final float TILT_THRESHOLD = 20f; //the degrees needed for a tilt to register

    private final int NUMBER_OF_PHRASES = 3;

    private boolean tiltMode;

    private TextView sampleText;
    private TextView typedText;
    private TableLayout table;
    private View[][] keyboard = new View[KEYBOARD_ROWS][KEYBOARD_COLS];
    private Key focusKey;
    private int focusX, focusY;

    private SensorManager sm;
    private Sensor accSensor, magSensor;
    private float[] accValues = new float[3];
    private float[] magValues = new float[3];
    private float pitch, roll;
    private float lastTime;
    private boolean canTilt;

    private int keystrokeCount; // number of strokes in a phrase
    private int phraseCount;
    private boolean done = false;
    private boolean firstKeystrokeInPhrase;
    private String sampleBuffer;
    private Random r = new Random();
    private ArrayList<Sample> samples;
    private long elapsedTimeForPhrase;
    private long timeStartOfPhrase;
    private String[] phrases;
    private BufferedWriter sd1, sd2;
    private File f1, f2;
    private String sd2Leader; // sd2Leader to identify conditions for data written to sd2 files.

    public StringBuilder typedBuffer = new StringBuilder();
    public boolean endOfPhrase;

    // compute typing speed in wpm, given text entered and time in ms
    public static float wpm(String text, long msTime)
    {
        float speed = text.length();
        speed = speed / (msTime / 1000.0f) * (60 / 5);
        return speed;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.keyboard_layout);

        Bundle b = getIntent().getExtras();
        String participantCode = b.getString("participantCode");
        String sessionCode = b.getString("sessionCode");
        String groupCode = b.getString("groupCode");
        tiltMode = b.getBoolean("tiltMode");
        String phrasesCode = b.getString("phrasesCode");
        String trialCode = b.getString("trialCode");

        sampleText = (TextView)findViewById(R.id.sampleText);
        typedText = (TextView)findViewById(R.id.typedText);
        table = (TableLayout)findViewById(R.id.keyboardLayout);

        if (tiltMode) {
            typedText.setFocusable(false);
            typedText.setFocusableInTouchMode(false);
            table.setVisibility(View.VISIBLE);
        }
        else {
            typedText.setFocusable(true);
            typedText.setFocusableInTouchMode(true);
            typedText.requestFocus();
            table.setVisibility(View.INVISIBLE);
        }

        typedText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    endOfPhrase = true;
                    keystroke();
                }
                return false;
            }
        });

        //get keys from layout and place in array
        for (int i = 0; i < KEYBOARD_ROWS; i++) {
            TableRow tRow = (TableRow) table.getChildAt(i);
            for (int j = 0; j < KEYBOARD_COLS; j++) {
                //account for size of the spacebar
                if (i == SPACE_ROW) {
                    if (j > SPACE_COL && j <= SPACE_COL + SPACE_WIDTH)
                        keyboard[i][j] = keyboard[SPACE_ROW][SPACE_COL];
                    else if (j > SPACE_COL + SPACE_WIDTH)
                        keyboard[i][j] = tRow.getChildAt(j - SPACE_WIDTH);
                    else
                        keyboard[i][j] = tRow.getChildAt(j);
                } else
                    keyboard[i][j] = tRow.getChildAt(j);

                if (tiltMode) {
                    keyboard[i][j].setFocusable(true);
                    keyboard[i][j].setFocusableInTouchMode(true);
                }
                else {
                    keyboard[i][j].setFocusable(false);
                    keyboard[i][j].setFocusableInTouchMode(false);
                }
            }
        }

        setFocus(0, 0);

        sm = (SensorManager)getSystemService(SENSOR_SERVICE);
        accSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magSensor = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        lastTime = System.nanoTime();


        if(phrasesCode.equals("phrase1")){
            phrases = getResources().getStringArray(R.array.phrase1);
        }
        else{
            phrases = getResources().getStringArray(R.array.phrase2);
        }

        samples = new ArrayList<Sample>();

        // make a working directory (if necessary) to store data files
        File dataDirectory = new File(Environment.getExternalStorageDirectory() + DATA_DIRECTORY);
        if (!dataDirectory.exists() && !dataDirectory.mkdirs())
        {
            Log.e(MYDEBUG, "ERROR --> FAILED TO CREATE DIRECTORY: " + DATA_DIRECTORY);
            super.onDestroy(); // cleanup
            this.finish(); // terminate
        }

        /*
         * The following do-loop creates data files for output and a string sd2Leader to write to the sd2
         * output files.  Both the filenames and the sd2Leader are constructed by combining the setup parameters
         * so that the filenames and sd2Leader are unique and also reveal the conditions used for the block of input.
         *
         * The block code begins "B01" and is incremented on each loop iteration until an available
         * filename is found.  The goal, of course, is to ensure data files are not inadvertently overwritten.
         */
        int blockNumber = 0;
        do
        {
            ++blockNumber;
            String blockCode = String.format(Locale.CANADA, "B%02d", blockNumber);
            String baseFilename = String.format("%s-%s-%s-%s-%s-%s-%s", APP, participantCode, sessionCode, blockCode, groupCode, trialCode, phrasesCode);
            f1 = new File(dataDirectory, baseFilename + ".sd1");
            f2 = new File(dataDirectory, baseFilename + ".sd2");

            // also make a comma-delimited leader that will begin each data line written to the sd2 file
            sd2Leader = String.format("%s,%s,%s,%s,%s,%s,%s", APP, participantCode, sessionCode, blockCode, groupCode, trialCode, phrasesCode);
        } while (f1.exists() || f2.exists());

        try
        {
            sd1 = new BufferedWriter(new FileWriter(f1));
            sd2 = new BufferedWriter(new FileWriter(f2));

            // output header in sd2 file
            sd2.write(SD2_HEADER, 0, SD2_HEADER.length());
            sd2.flush();

        } catch (IOException e)
        {
            Log.e(MYDEBUG, "ERROR OPENING DATA FILES! e=" + e.toString());
            super.onDestroy();
            this.finish();

        } // end file initialization

        phraseCount = 0;
        doNewPhrase();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        sm.registerListener(this, accSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sm.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_NORMAL);
        canTilt = true;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {
        // not needed, but we need to provide an implementation anyway
    }

    @Override
    public void onSensorChanged(SensorEvent se)
    {
        if (canTilt) {
            float now = System.nanoTime();
            if ((now - lastTime) / 1000000000f >= 0.4f) { //only update focus every 0.4 seconds at most
                lastTime = now;
                if (se.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
                    accValues = se.values;
                if (se.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
                    magValues = se.values;

                if (accValues != null && magValues != null) {
                    float[] R = new float[9];
                    float[] I = new float[9];
                    boolean success = SensorManager.getRotationMatrix(R, I, accValues, magValues);
                    if (success) {
                        float[] orientation = new float[3];
                        SensorManager.getOrientation(R, orientation);

                        pitch = orientation[1] * RADIANS_TO_DEGREES;
                        roll = -orientation[2] * RADIANS_TO_DEGREES;

                        if (-pitch > TILT_THRESHOLD) {
                            setFocus(true, true); //move focus down
                        } else if (pitch > TILT_THRESHOLD) {
                            setFocus(true, false); //move focus up
                        }

                        if (-roll > TILT_THRESHOLD) {
                            setFocus(false, true); //move focus right
                        } else if (roll > TILT_THRESHOLD) {
                            setFocus(false, false); //moves focus left
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        keystroke();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // Auto-generated method stub
    }

    @Override
    public void afterTextChanged(Editable s) {
        // Auto-generated method stub
    }

    //used for setting position of the focus key directly
    private void setFocus(int x, int y)
    {
        if (tiltMode && x >= 0 && x <= KEYBOARD_ROWS && y >= 0 && y <= KEYBOARD_COLS) {
            keyboard[x][y].requestFocus();
            focusKey = (Key) keyboard[x][y];
            focusX = x;
            focusY = y;
        }
    }

    //used for shifting the position of the focus key one at a time
    private void setFocus(boolean vertical, boolean positive)
    {
        if (tiltMode) {
            if (vertical) {
                if (positive) {
                    if (focusX == KEYBOARD_ROWS - 1)
                        focusX = 0;
                    else
                        focusX++;
                } else {
                    if (focusX == 0)
                        focusX = KEYBOARD_ROWS - 1;
                    else
                        focusX--;
                }
            } else {
                if (positive) {
                    if (focusY == KEYBOARD_COLS - 1)
                        focusY = 0;
                    else
                        focusY++;
                } else {
                    if (focusY == 0)
                        focusY = KEYBOARD_COLS - 1;
                    else
                        focusY--;
                }
            }

            keyboard[focusX][focusY].requestFocus();
            focusKey = (Key) keyboard[focusX][focusY];
        }
    }

    public void clickKeyboard(View v)
    {
        focusKey.keyAction();
        typedText.setText(typedBuffer);
        keystroke();
    }

    private void keystroke()
    {
        ++keystrokeCount;

        if (endOfPhrase)
        {
            elapsedTimeForPhrase = System.currentTimeMillis() - timeStartOfPhrase;
            --keystrokeCount; // don't count the final (ENTER) keystroke
            doEndOfPhrase();
        } else
        {
            if (tiltMode)
                typedText.setText(typedBuffer);

            if (firstKeystrokeInPhrase)
            {
                timeStartOfPhrase = System.currentTimeMillis();
                firstKeystrokeInPhrase = false;
            }
            elapsedTimeForPhrase = System.currentTimeMillis() - timeStartOfPhrase;
            samples.add(new Sample(elapsedTimeForPhrase, "*"));
        }
    }

    public void doNewPhrase()
    {
        String phrase = phrases[r.nextInt(phrases.length)];
        sampleBuffer = phrase.toUpperCase();
        sampleText.setText(sampleBuffer);
        typedBuffer.setLength(0);
        typedText.setText(typedBuffer);

        keystrokeCount = 0;
        samples.clear();
        endOfPhrase = false;
        firstKeystrokeInPhrase = true;

        if (!tiltMode)
            typedText.addTextChangedListener(this);
    }

    public void doEndOfPhrase()
    {
        typedText.removeTextChangedListener(this);
        canTilt = false;

        if (sampleBuffer == null)
            return; // "Enter" button pressed before anything entered

        String presentedPhrase = sampleBuffer.trim();
        String transcribedPhrase = typedText.getText().toString().trim();

        String resultsString = "Results\n\n";
        resultsString += "Phrase to Type:\n   " + presentedPhrase + "\n";
        resultsString += "Phrase Typed:\n   " + transcribedPhrase + "\n";

        StringBuilder sd2Data = new StringBuilder(100);
        sd2Data.append(String.format("%s,", sd2Leader));

        // output number of strokes (aka keystrokes)
        sd2Data.append(String.format(Locale.CANADA, "%d,", keystrokeCount));

        // output number of characters entered
        sd2Data.append(String.format(Locale.CANADA, "%d,", transcribedPhrase.length()));

        // output time in seconds
        float d = elapsedTimeForPhrase / 1000.0f;
        sd2Data.append(String.format(Locale.CANADA, "%.2f,", d));

        // append output time in minutes
        //d = elapsedTimeForPhrase / 1000.0f / 60.0f;

        // output speed in words per minute
        d = wpm(transcribedPhrase, elapsedTimeForPhrase);
        resultsString += String.format(Locale.CANADA, "Entry Speed: %.2f wpm\n", d);
        sd2Data.append(String.format(Locale.CANADA, "%f,", d));

        // output error rate for typedText text
        // MSD2 s1s2 = new MSD2(presentedPhrase, transcribedPhraseUncorrected);
        MSD s1s2 = new MSD(presentedPhrase, transcribedPhrase);
        d = (float)s1s2.getErrorRateNew();
        resultsString += String.format(Locale.CANADA, "Error Rate: %.2f%%\n", d);
        sd2Data.append(String.format(Locale.CANADA, "%f,", d));

        // output KSPC (keystrokes per character)
        d = (float)keystrokeCount / transcribedPhrase.length();
        resultsString += String.format(Locale.CANADA, "KSPC: %.4f\n\n", d);
        //resultsString += "Click OK to continue";
        sd2Data.append(String.format(Locale.CANADA, "%f\n", d)); // end of line too!

        // dump data
        StringBuilder sd1Stuff = new StringBuilder(100);
        sd1Stuff.append(String.format("%s\n", presentedPhrase));
        sd1Stuff.append(String.format("%s\n", transcribedPhrase));

        //Iterator<Sample> it = samples.iterator();
        //while (it.hasNext())
        //    sd1Stuff.append(String.format("%s\n", it.next()));

        for (Sample value : samples)
            sd1Stuff.append(String.format("%s\n", value));

        sd1Stuff.append("-----\n");

        // write to data files
        try
        {
            sd1.write(sd1Stuff.toString(), 0, sd1Stuff.length());
            sd1.flush();
            sd2.write(sd2Data.toString(), 0, sd2Data.length());
            sd2.flush();
        } catch (IOException e)
        {
            Log.e("MYDEBUG", "ERROR WRITING TO DATA FILE!\n" + e);
            super.onDestroy();
            this.finish();
        }

        // present results to user
        showResultsDialog(resultsString);

        // check if last phrase in block
        ++phraseCount;
        if (phraseCount < NUMBER_OF_PHRASES)
            doNewPhrase();
        else
            done = true; // will terminate on next tap (allows the user to see results from last phrase)
    }

    private void showResultsDialog(String text)
    {
        LayoutInflater inflater = (LayoutInflater)this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.results_dialog, (ViewGroup)findViewById(R.id.results_layout));

        // Set text
        TextView results = (TextView)layout.findViewById(R.id.resultsArea);
        results.setText(text);

        // Initialize the dialog
        AlertDialog.Builder parameters = new AlertDialog.Builder(this);
        parameters.setView(layout).setCancelable(false).setPositiveButton("OK", new
                DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int id)
                    {
                        dialog.cancel(); // close this dialog
                        canTilt = true;
                        if (done)
                            doDone();
                    }
                }).show();
    }

    private void doDone()
    {
        try
        {
            sd1.close();
            sd2.close();

            /*
             * Make the saved data files visible in Windows Explorer. There seems to be bug doing
             * this with Android 4.4. I'm using the following code, instead of sendBroadcast.
             * See...
             *
             * http://code.google.com/p/android/issues/detail?id=38282
             */
            MediaScannerConnection.scanFile(this, new String[] {f1.getAbsolutePath(), f2.getAbsolutePath()}, null,null);

        } catch (IOException e)
        {
            Log.e(MYDEBUG, "ERROR CLOSING DATA FILES! e=" + e);
        }

        startActivity(new Intent(getApplicationContext(), SetupActivity.class));
        //super.onDestroy();
        this.finish();
    }

    private class Sample
    {
        private long time;
        private String key;

        Sample(long timeArg, String keyArg)
        {
            time = timeArg;
            key = keyArg;
        }

        public String toString()
        {
            return time + ", " + key;
        }
    }
}