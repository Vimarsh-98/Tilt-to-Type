package com.eecs4443.tilttotype;

public interface Key {
    void initialize();
    void keyAction();
}
